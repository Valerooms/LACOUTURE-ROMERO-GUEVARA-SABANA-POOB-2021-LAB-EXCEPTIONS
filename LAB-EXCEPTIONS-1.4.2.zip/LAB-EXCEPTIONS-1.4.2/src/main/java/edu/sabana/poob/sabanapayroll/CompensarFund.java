package edu.sabana.poob.sabanapayroll;

public class CompensarFund {
}
